'use strict';if(typeof module!=='undefined'&&module!==null&&eval('typeof require')!=='undefined'&&eval('require')!==null&&'main'in eval('require')&&eval('typeof require.main')!=='undefined'&&eval('require.main')!==null){var ORIGINAL_MAIN_MODULE=module;if(module!==eval('require.main')&&'paths'in module&&'paths'in eval('require.main')&&typeof __dirname!=='undefined'&&__dirname!==null)module.paths=eval('require.main.paths').concat(module.paths.filter(function(path){return eval('require.main.paths').includes(path)}))};if(typeof window==='undefined'||window===null)var window=(typeof global==='undefined'||global===null)?{}:global;(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory((function webpackLoadOptionalExternalModule() { try { return require("ua-parser-js"); } catch(e) {} }()));
	else if(typeof define === 'function' && define.amd)
		define("errorreporter", ["ua-parser-js"], factory);
	else if(typeof exports === 'object')
		exports["errorreporter"] = factory((function webpackLoadOptionalExternalModule() { try { return require("ua-parser-js"); } catch(e) {} }()));
	else
		root["errorreporter"] = factory(root["ua-parser-js"]);
})(this, function(__WEBPACK_EXTERNAL_MODULE__1__) {
return /******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BASE_ISSUE: function() { return /* binding */ BASE_ISSUE; },
/* harmony export */   BROWSER_ISSUE: function() { return /* binding */ BROWSER_ISSUE; },
/* harmony export */   determineGlobalContext: function() { return /* binding */ determineGlobalContext; },
/* harmony export */   errorHandler: function() { return /* binding */ _errorHandler; },
/* harmony export */   globalContext: function() { return /* binding */ globalContext; }
/* harmony export */ });
/* module decorator */ module = __webpack_require__.hmd(module);
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module errorreporter *//* !
    region header
    [Project page](https://torben.website/errorreporter)

    Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/function _createForOfIteratorHelperLoose(r,e){var t="undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(t)return(t=t.call(r)).next.bind(t);if(Array.isArray(r)||(t=_unsupportedIterableToArray(r))||e&&r&&"number"==typeof r.length){t&&(r=t);var o=0;return function(){return o>=r.length?{done:!0}:{done:!1,value:r[o++]}}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}function _unsupportedIterableToArray(r,a){if(r){if("string"==typeof r)return _arrayLikeToArray(r,a);var t={}.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?_arrayLikeToArray(r,a):void 0}}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function _extends(){return _extends=Object.assign?Object.assign.bind():function(n){for(var t,e=1;e<arguments.length;e++)for(var r in t=arguments[e],t)({}).hasOwnProperty.call(t,r)&&(n[r]=t[r]);return n},_extends.apply(null,arguments)}var determineGlobalContext=function(){return"undefined"==typeof globalThis?"undefined"==typeof window?"undefined"==typeof __webpack_require__.g? false?0:module:"window"in __webpack_require__.g?__webpack_require__.g.window:__webpack_require__.g:window:globalThis};var globalContext=determineGlobalContext();var _errorHandler=function(errorMessage,url,lineNumber,columnNumber,error){var issue=_extends({},BROWSER_ISSUE),location=Object.prototype.hasOwnProperty.call(globalContext,"window")&&Object.prototype.hasOwnProperty.call(globalContext.window,"location")?globalContext.window.location:_errorHandler.location;/*
        Sends an error report to current requested domain via ajax in JSON
        format. Supported by Chrome 13+, Firefox 6.0+, Internet Explorer 5.5+,
        Opera 11.60+, Safari 5.1+
    */// URL to send error messages to.
_errorHandler.reportPath||(_errorHandler.reportPath="/__error_report__"),Object.prototype.hasOwnProperty.call(_errorHandler,"failedHandler")||(_errorHandler.failedHandler=function(error){"alert"in globalContext&&globalContext.alert(error)}),Object.prototype.hasOwnProperty.call(_errorHandler,"issuesToIgnore")||(_errorHandler.issuesToIgnore=[/* eslint-disable max-len */{browser:{name:"IE"}},{browser:{major:/[123456789]|10/,name:"Firefox"}},{errorMessage:/Access is denied/},{errorMessage:/Das System kann auf die Datei nicht zugreifen/},{errorMessage:/Der RPC-Server ist nicht verfügbar/},{errorMessage:"Error loading script"},{errorMessage:/Für diesen Vorgang ist nicht genügend Speicher verfügbar/},{errorMessage:/^In den Microsoft-Interneterweiterungen ist ein interner Fehler aufgetreten\./},{errorMessage:/^IndexSizeError: Index or size is negative or greater than the allowed amount/},{errorMessage:/Nicht genügend Arbeitsspeicher/},{errorMessage:/^NS_ERROR[A-Z_]*:.*/},{errorMessage:/Permission denied to access property/},{errorMessage:/^QuotaExceededError:/},{errorMessage:/^ReferenceError: "gapi" is not defined\..*/},{errorMessage:"Script error."},{errorMessage:/^SecurityError/},{errorMessage:/TypeError: Expected argument of type object, but instead had type object/},{errorMessage:/^TypeError: undefined is not an object \(evaluating 'window\.__firefox__\..+'\)$/},{errorMessage:/Uncaught SecurityError: Failed to read the 'localStorage' property from 'Window': Access is denied/},{errorMessage:/Uncaught ReferenceError: ztePageScrollModule is not defined/},{errorMessage:"Unbekannter Fehler"},{errorMessage:"UnknownError"},{errorMessage:/^uncaught exception: /},{errorMessage:/Zugriff verweigert/}/* eslint-enable max-len */]),Array.isArray(_errorHandler.additionalIssuesToIgnore)&&(_errorHandler.issuesToIgnore=_errorHandler.issuesToIgnore.concat(_errorHandler.additionalIssuesToIgnore)),Object.prototype.hasOwnProperty.call(_errorHandler,"issueToIgnoreHandler")||(_errorHandler.issueToIgnoreHandler=function(issue,issueToIgnore){issueToIgnore.errorMessage||globalContext.alert("Your technology \""+issue.technologyDescription+"\" to display this website isn't supported any more. Please upgrade your browser engine.")}),Object.prototype.hasOwnProperty.call(_errorHandler,"reportedHandler")||(_errorHandler.reportedHandler=function(){// Do nothing.
});try{issue.errorMessage=errorMessage+""||"Unclear";// Checks if given object completely matches given match object.
for(var _step,issueToIgnore,_matches=function(issueItem,issueItemSpecification){if("[object Object]"===Object.prototype.toString.call(issueItemSpecification)&&"[object Object]"===Object.prototype.toString.call(issueItem)){for(var key,_i=0,_Object$keys=Object.keys(issueItemSpecification);_i<_Object$keys.length;_i++)if(key=_Object$keys[_i],!(issueItem[key]&&_matches(issueItem[key],issueItemSpecification[key])))return!1;return!0}return"[object RegExp]"===Object.prototype.toString.call(issueItemSpecification)?issueItemSpecification.test(issueItem+""):issueItemSpecification===issueItem},_iterator=_createForOfIteratorHelperLoose(_errorHandler.issuesToIgnore);!(_step=_iterator()).done;)issueToIgnore=_step.value,_matches(issue,issueToIgnore)&&_errorHandler.issueToIgnoreHandler(issue,issueToIgnore);var toString=function(value){return["boolean","number"].includes(typeof value)||null===value?value+"":"\""+/* eslint-disable @typescript-eslint/no-base-to-string */(value+""/* eslint-enable @typescript-eslint/no-base-to-string */).replace(/\\/g,"\\\\").replace(/\r\n|\r/g,"\\n").replace(/"/g,"\\\"")+"\""},_serialize=function(value){if(null!==value&&"object"==typeof value&&!(value instanceof RegExp)){if(Array.isArray(value)){for(var _step2,item,_result="[",_iterator2=_createForOfIteratorHelperLoose(value);!(_step2=_iterator2()).done;)item=_step2.value,"["!==_result&&(_result+=","),_result+=_serialize(item);return _result+"]"}for(var key,result="{",_i2=0,_Object$keys2=Object.keys(value);_i2<_Object$keys2.length;_i2++)key=_Object$keys2[_i2],"{"!==result&&(result+=","),result+="\""+key+"\":"+_serialize(value[key]);return result+"}"}return toString(value)},errorKey=errorMessage+"#"+location.href+"#"+(lineNumber+""+"#"+(columnNumber+""));if(!Object.prototype.hasOwnProperty.call(_errorHandler.reported,errorKey)){_errorHandler.reported[errorKey]=!0;var portPrefix=location.port?": "+location.port:"",headers={"Content-type":"application/json"};globalContext.fetch(location.protocol+"//"+location.hostname+portPrefix+_errorHandler.reportPath,{body:_serialize({absoluteURL:location.href,columnNumber:columnNumber,errorMessage:errorMessage,issuesToIgnore:_errorHandler.issuesToIgnore,lineNumber:lineNumber,stack:null==error?void 0:error.stack,technologyDescription:issue.technologyDescription,url:url,userAgent:Object.prototype.hasOwnProperty.call(globalContext,"window")&&Object.prototype.hasOwnProperty.call(globalContext.window,"navigator")&&globalContext.window.navigator.userAgent?globalContext.window.navigator.userAgent:"unclear"}),headers:Object.prototype.hasOwnProperty.call(globalContext,"Headers")?new globalContext.Headers(headers):headers,method:"PUT"}).then(_errorHandler.reportedHandler).catch(function(error){_errorHandler.failedHandler(error)})}}catch(error){_errorHandler.failedHandler(error)}};_errorHandler.location={hostname:"localhost",href:"http://localhost",protocol:"http"},_errorHandler.reported={};var BASE_ISSUE={errorMessage:"",technologyDescription:"Unclear",ua:"",engine:{name:"",version:""},os:{name:"",version:""}};var BROWSER_ISSUE=_extends({},BASE_ISSUE);try{BROWSER_ISSUE=_extends({},BROWSER_ISSUE,__webpack_require__(1)())}catch(_unused){// Ignore error.
}try{if(BROWSER_ISSUE.browser){var _BROWSER_ISSUE$device;BROWSER_ISSUE.technologyDescription=BROWSER_ISSUE.browser.name+" "+BROWSER_ISSUE.browser.major+" ("+(BROWSER_ISSUE.browser.version+" | "+BROWSER_ISSUE.engine.name+" ")+(BROWSER_ISSUE.engine.version+") | "+BROWSER_ISSUE.os.name+" ")+BROWSER_ISSUE.os.version,null!=(_BROWSER_ISSUE$device=BROWSER_ISSUE.device)&&_BROWSER_ISSUE$device.model&&BROWSER_ISSUE.device.type&&BROWSER_ISSUE.device.vendor&&(BROWSER_ISSUE.technologyDescription+=" | "+BROWSER_ISSUE.device.model+" "+(BROWSER_ISSUE.device.type+" "+BROWSER_ISSUE.device.vendor))}}catch(error){console.warn(error)}/* harmony default export */ __webpack_exports__["default"] = (_errorHandler);// Register extended error handler globally.
globalContext.addEventListener&&(globalContext.addEventListener("error",function(event){_errorHandler(event.message,event.source,event.lineno,event.colno,event.error,event.filename)}),globalContext.addEventListener("unhandledrejection",function(event){_errorHandler(event.reason)}));

/***/ }),
/* 1 */
/***/ (function(module) {

if(typeof __WEBPACK_EXTERNAL_MODULE__1__ === 'undefined') { var e = new Error("Cannot find module 'ua-parser-js'"); e.code = 'MODULE_NOT_FOUND'; throw e; }

module.exports = __WEBPACK_EXTERNAL_MODULE__1__;

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	!function() {
/******/ 		__webpack_require__.hmd = function(module) {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: function() {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(0);
/******/ 	
/******/ 	return __webpack_exports__;
/******/ })()
;
});