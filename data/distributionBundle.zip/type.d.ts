import { Mapping, RecursivePartial } from 'clientnode/type';
export interface Issue<Type = string> {
    errorMessage: Type;
    technologyDescription: Type;
    ua: Type;
    browser?: {
        name: Type;
        version: Type;
        major: Type;
    };
    cpu?: {
        architecture: Type;
    };
    device?: {
        model?: Type;
        type?: Type;
        vendor?: Type;
    };
    engine: {
        name: Type;
        version: Type;
    };
    os: {
        name: Type;
        version: Type;
    };
}
export interface BaseLocation {
    hostname: string;
    href: string;
    port?: string;
    protocol: string;
}
export declare type IssueSpecification<Type = null | RegExp | string> = RecursivePartial<Issue<Type>>;
export declare type NativeErrorHandler = (errorMessage: Event | string, url?: string, lineNumber?: number, columnNumber?: number, error?: Error, ...additionalParameter: Array<unknown>) => (false | void);
export declare type ErrorHandler = NativeErrorHandler & {
    additionalIssuesToIgnore: Array<IssueSpecification>;
    callbackBackup: NativeErrorHandler;
    failedHandler: (error: Error) => void;
    issuesToIgnore: Array<IssueSpecification>;
    issueToIgnoreHandler: (issue: Issue, issueToIgnore: IssueSpecification) => void;
    location: BaseLocation;
    reported: Mapping<true>;
    reportedHandler: (response: Response) => Promise<void> | void;
    reportPath: string;
};
